
public class Stringifier extends GamePrinter {

}
