
public abstract class GamePrinter {

}
